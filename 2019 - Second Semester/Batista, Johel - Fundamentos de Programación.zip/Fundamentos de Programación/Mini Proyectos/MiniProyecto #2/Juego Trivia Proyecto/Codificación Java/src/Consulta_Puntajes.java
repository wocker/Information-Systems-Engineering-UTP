public class Consulta_Puntajes {

  public void imprimirPantalla(){
    System.out.println("Usuario-----------------Puntaje");

  }
}
