public class Juego {
  public void imprimirHola(){
    System.out.println("Hola mundo");
  }


}
