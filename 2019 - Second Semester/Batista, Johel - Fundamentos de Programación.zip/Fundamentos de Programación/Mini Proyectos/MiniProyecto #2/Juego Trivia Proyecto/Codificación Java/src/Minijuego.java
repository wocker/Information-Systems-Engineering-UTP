public class Minijuego {

}
